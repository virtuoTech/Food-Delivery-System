abstract class Person {
    private String name;
    public abstract String getName(String name);
}

