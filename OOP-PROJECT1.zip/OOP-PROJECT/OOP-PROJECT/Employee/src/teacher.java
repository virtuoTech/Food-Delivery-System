class Teacher extends Person {
    @Override
    public String getName(String name) {
        System.out.println("name of Teacher is");
        return name;
    }}
