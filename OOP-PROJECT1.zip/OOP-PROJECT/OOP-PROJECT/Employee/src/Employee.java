public class Employee {
    int id=2;
    String name="Ali";

    void details(){
        System.out.println("Employee id = "+id);
        System.out.println("Employee Name = "+name);
    }
}
