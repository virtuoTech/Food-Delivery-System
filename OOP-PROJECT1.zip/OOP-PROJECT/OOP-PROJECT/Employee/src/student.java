class Student extends Person {
    @Override
    public String getName(String name) {
        System.out.println("name of Student is");
        return name;
    }}
