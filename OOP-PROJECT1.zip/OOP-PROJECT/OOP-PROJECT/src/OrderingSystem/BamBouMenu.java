package OrderingSystem;

public class BamBouMenu {

public String main_title,sub_title,box_title;
    
public String SetTitleBurger(){
       main_title="Bam-Bou Menu";
return main_title; 
}
    public String SubTitle_1(){
       sub_title="Soups";
return sub_title; 
}
    public String SetBoxTitle_1(){
       box_title="C.Corn Soup";
return box_title; 
}
     public String SetBoxTitle_2(){
       box_title="BamBou Hot Soup";
return box_title; 
}
      public String SetBoxTitle_3(){
       box_title="Red Hot Soup";
return box_title; 
}
       public String SetBoxTitle_4(){
       box_title="White Hot Soup";
return box_title; 
}
        public String SetBoxTitle_5(){
       box_title="Szechuan Soup";
return box_title; 
}
         public String SetBoxTitle_6(){
       box_title="Thai Soup";
return box_title; 
}
          public String SetBoxTitle_7(){
       box_title="Manchow Soup";
return box_title; 
}
           public String SetBoxTitle_8(){
       box_title="Wonton Soup";
return box_title; 
}
           public String SubTitle_2(){
       sub_title="Bevreges";
return sub_title; 
}
           public String SetBoxTitle_9(){
       box_title="Water";
return box_title; 
}
           public String SetBoxTitle_10(){
       box_title="Pepsi Can";
return box_title; 
}
           public String SetBoxTitle_11(){
       box_title="Fresh lime";
return box_title; 
}
           public String SetBoxTitle_12(){
       box_title="Sprite Can";
return box_title; 
}
           public String SubTitle_3(){
       sub_title="Rice";
return sub_title; 
}
      public String SetBoxTitle_13(){
       box_title="V.Fried Rice";
return box_title; 
}
 public String SetBoxTitle_14(){
       box_title="Egg Rice";
return box_title; 
}
  public String SetBoxTitle_15(){
       box_title="C.Fried Rice";
return box_title; 
}
   public String SetBoxTitle_16(){
       box_title="Steamed Rice";
return box_title; 
}
    public String SubTitle_4(){
       sub_title="Prawns/Fish";
return sub_title; 
}
    public String SetBoxTitle_17(){
       box_title="Crisp Rolls";
return box_title; 
}
    public String SetBoxTitle_18(){
       box_title="Wontons";
return box_title; 
}
    public String SetBoxTitle_19(){
       box_title="C.Strips";
return box_title; 
}
    public String SetBoxTitle_20(){
       box_title="Spicy Prawn";
return box_title; 
}
    public String SetBoxTitle_21(){
       box_title="Sweet Prawn";
return box_title; 
}
    public String SetBoxTitle_22(){
       box_title="Lotus Fish";
return box_title; 
}
    public String SetBoxTitle_23(){
       box_title="Twister Fish";
return box_title; 
}  
    
    
}
