package OrderingSystem;

import AdminPanel.AdminClass;

public class Product extends AdminClass {
private String ProductCategory;
    public Product(String ProductCategory, String ProductName, int ProductId) {
        
        this.ProductCategory = ProductCategory;
    }

    public String getProductCategory() {
        return ProductCategory;
    }
    
    
    
    
}
