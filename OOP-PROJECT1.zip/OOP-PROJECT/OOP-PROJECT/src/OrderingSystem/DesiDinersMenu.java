package OrderingSystem;

public class DesiDinersMenu {
  public String main_title,sub_title,box_title;

public String SetTitleBurger(){
       main_title="Desi Diner's Menu";
return main_title; 
}
    public String SubTitle_1(){
       sub_title="Non. Vegetarian";
return sub_title; 
}
    public String SetBoxTitle_1(){
       box_title="Chicken Briyani";
return box_title; 
}
     public String SetBoxTitle_2(){
       box_title="Tawa Biryani";
return box_title; 
}
      public String SetBoxTitle_3(){
       box_title="Chicken Fried Rice";
return box_title; 
}
       public String SetBoxTitle_4(){
       box_title="Chilly Chicken";
return box_title; 
}
        public String SetBoxTitle_5(){
       box_title="Garlic Chicken";
return box_title; 
}
         public String SetBoxTitle_6(){
       box_title="Chicken Majestic";
return box_title; 
}
          public String SetBoxTitle_7(){
       box_title="Chicken Kabab";
return box_title; 
}
           public String SetBoxTitle_8(){
       box_title="Chicken Pakoda";
return box_title; 
}
           public String SubTitle_2(){
       sub_title="Bevreges";
return sub_title; 
}
           public String SetBoxTitle_9(){
       box_title="Water";
return box_title; 
}
           public String SetBoxTitle_10(){
       box_title="Slice";
return box_title; 
}
           public String SetBoxTitle_11(){
       box_title="Sprite";
return box_title; 
}
           public String SetBoxTitle_12(){
       box_title="Coca Cola";
return box_title; 
}
           public String SubTitle_3(){
       sub_title="Vegetarian";
return sub_title; 
}
      public String SetBoxTitle_13(){
       box_title="Veg.Biryani";
return box_title; 
}
 public String SetBoxTitle_14(){
       box_title="Beef Masala";
return box_title; 
}
  public String SetBoxTitle_15(){
       box_title="Veg.Rice";
return box_title; 
}
   public String SetBoxTitle_16(){
       box_title="Veg.Noodles";
return box_title; 
}
    public String SubTitle_4(){
       sub_title="Qahwa / Chai";
return sub_title; 
}
    public String SetBoxTitle_17(){
       box_title="Black Qahwa";
return box_title; 
}
    public String SetBoxTitle_18(){
       box_title="Green Qahwa";
return box_title; 
}
    public String SetBoxTitle_19(){
       box_title="Mint Qahwa";
return box_title; 
}
    public String SetBoxTitle_20(){
       box_title="Long Chai";
return box_title; 
}
    public String SetBoxTitle_21(){
       box_title="Doodh Patti";
return box_title; 
}
    public String SetBoxTitle_22(){
       box_title="Adrak Chai";
return box_title; 
}
    public String SetBoxTitle_23(){
       box_title="Elaechi Chai";
return box_title; 
}  
}
