package OrderingSystem;

import DefaultPanel.Login;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Res_Menus extends javax.swing.JFrame {
static int counter=0;
static ArrayList<String> labelsTexts = new ArrayList<>();
    public Res_Menus() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titlelabel = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        dealslabel = new javax.swing.JLabel();
        Product1 = new javax.swing.JCheckBox();
        Product2 = new javax.swing.JCheckBox();
        Product3 = new javax.swing.JCheckBox();
        Product4 = new javax.swing.JCheckBox();
        Product5 = new javax.swing.JCheckBox();
        Product6 = new javax.swing.JCheckBox();
        Product7 = new javax.swing.JCheckBox();
        Product8 = new javax.swing.JCheckBox();
        dealtext1 = new javax.swing.JTextField();
        dealtext2 = new javax.swing.JTextField();
        dealtext3 = new javax.swing.JTextField();
        dealtext4 = new javax.swing.JTextField();
        dealtext5 = new javax.swing.JTextField();
        dealtext6 = new javax.swing.JTextField();
        dealtext7 = new javax.swing.JTextField();
        dealtext8 = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        drinkslabel = new javax.swing.JLabel();
        drink1 = new javax.swing.JCheckBox();
        drink2 = new javax.swing.JCheckBox();
        drink3 = new javax.swing.JCheckBox();
        drink4 = new javax.swing.JCheckBox();
        drinktext1 = new javax.swing.JTextField();
        drinktext2 = new javax.swing.JTextField();
        drinktext3 = new javax.swing.JTextField();
        drinktext4 = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        drinkslabel1 = new javax.swing.JLabel();
        drink5 = new javax.swing.JCheckBox();
        drink6 = new javax.swing.JCheckBox();
        drink7 = new javax.swing.JCheckBox();
        drink8 = new javax.swing.JCheckBox();
        dealtext13 = new javax.swing.JTextField();
        dealtext14 = new javax.swing.JTextField();
        dealtext15 = new javax.swing.JTextField();
        dealtext16 = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        desertslabel = new javax.swing.JLabel();
        desert1 = new javax.swing.JCheckBox();
        desert2 = new javax.swing.JCheckBox();
        desert3 = new javax.swing.JCheckBox();
        desert4 = new javax.swing.JCheckBox();
        desertstext1 = new javax.swing.JTextField();
        desertstext2 = new javax.swing.JTextField();
        desertstext3 = new javax.swing.JTextField();
        desertstext4 = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        drinkslabel3 = new javax.swing.JLabel();
        drink13 = new javax.swing.JCheckBox();
        drink14 = new javax.swing.JCheckBox();
        drink15 = new javax.swing.JCheckBox();
        drink16 = new javax.swing.JCheckBox();
        dealtext21 = new javax.swing.JTextField();
        dealtext22 = new javax.swing.JTextField();
        dealtext23 = new javax.swing.JTextField();
        dealtext24 = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        sublabel = new javax.swing.JLabel();
        itemtext4 = new javax.swing.JTextField();
        item4 = new javax.swing.JCheckBox();
        itemtext2 = new javax.swing.JTextField();
        item2 = new javax.swing.JCheckBox();
        itemtext3 = new javax.swing.JTextField();
        item3 = new javax.swing.JCheckBox();
        itemtext5 = new javax.swing.JTextField();
        item5 = new javax.swing.JCheckBox();
        itemtext6 = new javax.swing.JTextField();
        item6 = new javax.swing.JCheckBox();
        itemtext1 = new javax.swing.JTextField();
        item1 = new javax.swing.JCheckBox();
        item7 = new javax.swing.JCheckBox();
        itemtext7 = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        Clear = new javax.swing.JButton();
        Cart = new javax.swing.JButton();
        signout = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        titlelabel.setFont(new java.awt.Font("Segoe Print", 1, 48)); // NOI18N
        titlelabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titlelabel.setText("Menu");
        titlelabel.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                titlelabelFocusGained(evt);
            }
        });
        getContentPane().add(titlelabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, 550, 70));

        jPanel1.setBackground(new java.awt.Color(102, 213, 213));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        dealslabel.setFont(new java.awt.Font("Segoe Print", 1, 24)); // NOI18N
        dealslabel.setText("Deals");
        jPanel1.add(dealslabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 330, -1));

        Product1.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        Product1.setText("deal1");
        Product1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Product1ActionPerformed(evt);
            }
        });
        jPanel1.add(Product1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        Product2.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        Product2.setText("deal2");
        Product2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Product2ActionPerformed(evt);
            }
        });
        jPanel1.add(Product2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        Product3.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        Product3.setText("deal3");
        Product3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Product3ActionPerformed(evt);
            }
        });
        jPanel1.add(Product3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, -1));

        Product4.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        Product4.setText("deal4");
        Product4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Product4ActionPerformed(evt);
            }
        });
        jPanel1.add(Product4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));

        Product5.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        Product5.setText("deal5");
        Product5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Product5ActionPerformed(evt);
            }
        });
        jPanel1.add(Product5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, -1, -1));

        Product6.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        Product6.setText("deal6");
        Product6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Product6ActionPerformed(evt);
            }
        });
        jPanel1.add(Product6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, -1, -1));

        Product7.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        Product7.setText("deal7");
        Product7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Product7ActionPerformed(evt);
            }
        });
        jPanel1.add(Product7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, -1, -1));

        Product8.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        Product8.setText("deal8");
        Product8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Product8ActionPerformed(evt);
            }
        });
        jPanel1.add(Product8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, -1, -1));

        dealtext1.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        dealtext1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        dealtext1.setText("0");
        dealtext1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        dealtext1.setRequestFocusEnabled(false);
        dealtext1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dealtext1ActionPerformed(evt);
            }
        });
        dealtext1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dealtext1KeyTyped(evt);
            }
        });
        jPanel1.add(dealtext1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 80, 80, 20));

        dealtext2.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        dealtext2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        dealtext2.setText("0");
        dealtext2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        dealtext2.setRequestFocusEnabled(false);
        dealtext2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dealtext2ActionPerformed(evt);
            }
        });
        dealtext2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dealtext2KeyTyped(evt);
            }
        });
        jPanel1.add(dealtext2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 130, 80, 20));

        dealtext3.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        dealtext3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        dealtext3.setText("0");
        dealtext3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        dealtext3.setRequestFocusEnabled(false);
        dealtext3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dealtext3ActionPerformed(evt);
            }
        });
        dealtext3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dealtext3KeyTyped(evt);
            }
        });
        jPanel1.add(dealtext3, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 180, 80, 20));

        dealtext4.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        dealtext4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        dealtext4.setText("0");
        dealtext4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        dealtext4.setRequestFocusEnabled(false);
        dealtext4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dealtext4ActionPerformed(evt);
            }
        });
        dealtext4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dealtext4KeyTyped(evt);
            }
        });
        jPanel1.add(dealtext4, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 230, 80, 20));

        dealtext5.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        dealtext5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        dealtext5.setText("0");
        dealtext5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        dealtext5.setRequestFocusEnabled(false);
        dealtext5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dealtext5ActionPerformed(evt);
            }
        });
        dealtext5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dealtext5KeyTyped(evt);
            }
        });
        jPanel1.add(dealtext5, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 280, 80, 20));

        dealtext6.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        dealtext6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        dealtext6.setText("0");
        dealtext6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        dealtext6.setRequestFocusEnabled(false);
        dealtext6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dealtext6ActionPerformed(evt);
            }
        });
        dealtext6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dealtext6KeyTyped(evt);
            }
        });
        jPanel1.add(dealtext6, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 330, 80, 20));

        dealtext7.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        dealtext7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        dealtext7.setText("0");
        dealtext7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        dealtext7.setRequestFocusEnabled(false);
        dealtext7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dealtext7ActionPerformed(evt);
            }
        });
        dealtext7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dealtext7KeyTyped(evt);
            }
        });
        jPanel1.add(dealtext7, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 380, 80, 20));

        dealtext8.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        dealtext8.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        dealtext8.setText("0");
        dealtext8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        dealtext8.setRequestFocusEnabled(false);
        dealtext8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dealtext8ActionPerformed(evt);
            }
        });
        dealtext8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dealtext8KeyTyped(evt);
            }
        });
        jPanel1.add(dealtext8, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 430, 80, 20));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 390, 500));

        jPanel2.setBackground(new java.awt.Color(102, 213, 213));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        drinkslabel.setFont(new java.awt.Font("Segoe Print", 1, 24)); // NOI18N
        drinkslabel.setText("Drinks");
        jPanel2.add(drinkslabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 190, -1));

        drink1.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        drink1.setText("drink1");
        drink1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drink1ActionPerformed(evt);
            }
        });
        jPanel2.add(drink1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        drink2.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        drink2.setText("drink2");
        drink2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drink2ActionPerformed(evt);
            }
        });
        jPanel2.add(drink2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        drink3.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        drink3.setText("drink3");
        drink3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drink3ActionPerformed(evt);
            }
        });
        jPanel2.add(drink3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, -1));

        drink4.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        drink4.setText("drink4");
        drink4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drink4ActionPerformed(evt);
            }
        });
        jPanel2.add(drink4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));

        drinktext1.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        drinktext1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        drinktext1.setText("0");
        drinktext1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        drinktext1.setRequestFocusEnabled(false);
        drinktext1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drinktext1ActionPerformed(evt);
            }
        });
        drinktext1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                drinktext1KeyTyped(evt);
            }
        });
        jPanel2.add(drinktext1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 80, 80, 20));

        drinktext2.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        drinktext2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        drinktext2.setText("0");
        drinktext2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        drinktext2.setRequestFocusEnabled(false);
        drinktext2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drinktext2ActionPerformed(evt);
            }
        });
        drinktext2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                drinktext2KeyTyped(evt);
            }
        });
        jPanel2.add(drinktext2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 130, 80, 20));

        drinktext3.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        drinktext3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        drinktext3.setText("0");
        drinktext3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        drinktext3.setRequestFocusEnabled(false);
        drinktext3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drinktext3ActionPerformed(evt);
            }
        });
        drinktext3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                drinktext3KeyTyped(evt);
            }
        });
        jPanel2.add(drinktext3, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 180, 80, 20));

        drinktext4.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        drinktext4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        drinktext4.setText("0");
        drinktext4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        drinktext4.setRequestFocusEnabled(false);
        drinktext4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drinktext4ActionPerformed(evt);
            }
        });
        drinktext4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                drinktext4KeyTyped(evt);
            }
        });
        jPanel2.add(drinktext4, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 230, 80, 20));

        jPanel3.setBackground(new java.awt.Color(225, 225, 225));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        drinkslabel1.setFont(new java.awt.Font("Segoe Print", 1, 24)); // NOI18N
        drinkslabel1.setText("Drinks");
        jPanel3.add(drinkslabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 330, -1));

        drink5.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        drink5.setText("drink1");
        drink5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drink5ActionPerformed(evt);
            }
        });
        jPanel3.add(drink5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        drink6.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        drink6.setText("drink2");
        drink6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drink6ActionPerformed(evt);
            }
        });
        jPanel3.add(drink6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        drink7.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        drink7.setText("drink3");
        drink7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drink7ActionPerformed(evt);
            }
        });
        jPanel3.add(drink7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, -1));

        drink8.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        drink8.setText("drink4");
        drink8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drink8ActionPerformed(evt);
            }
        });
        jPanel3.add(drink8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));

        dealtext13.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        dealtext13.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        dealtext13.setText("0");
        dealtext13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        dealtext13.setRequestFocusEnabled(false);
        dealtext13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dealtext13ActionPerformed(evt);
            }
        });
        dealtext13.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dealtext13KeyTyped(evt);
            }
        });
        jPanel3.add(dealtext13, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 80, 80, 20));

        dealtext14.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        dealtext14.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        dealtext14.setText("0");
        dealtext14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        dealtext14.setRequestFocusEnabled(false);
        dealtext14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dealtext14ActionPerformed(evt);
            }
        });
        dealtext14.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dealtext14KeyTyped(evt);
            }
        });
        jPanel3.add(dealtext14, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 130, 80, 20));

        dealtext15.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        dealtext15.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        dealtext15.setText("0");
        dealtext15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        dealtext15.setRequestFocusEnabled(false);
        dealtext15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dealtext15ActionPerformed(evt);
            }
        });
        dealtext15.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dealtext15KeyTyped(evt);
            }
        });
        jPanel3.add(dealtext15, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 180, 80, 20));

        dealtext16.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        dealtext16.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        dealtext16.setText("0");
        dealtext16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        dealtext16.setRequestFocusEnabled(false);
        dealtext16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dealtext16ActionPerformed(evt);
            }
        });
        dealtext16.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dealtext16KeyTyped(evt);
            }
        });
        jPanel3.add(dealtext16, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 230, 80, 20));

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 110, 270, 280));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 110, 270, 280));

        jPanel4.setBackground(new java.awt.Color(102, 213, 213));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        desertslabel.setFont(new java.awt.Font("Segoe Print", 1, 24)); // NOI18N
        desertslabel.setText("Deserts");
        jPanel4.add(desertslabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 260, 40));

        desert1.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        desert1.setText("Deserts1");
        desert1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                desert1ActionPerformed(evt);
            }
        });
        jPanel4.add(desert1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        desert2.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        desert2.setText("Deserts2");
        desert2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                desert2ActionPerformed(evt);
            }
        });
        jPanel4.add(desert2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        desert3.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        desert3.setText("Deserts3");
        desert3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                desert3ActionPerformed(evt);
            }
        });
        jPanel4.add(desert3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, -1));

        desert4.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        desert4.setText("Deserts4");
        desert4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                desert4ActionPerformed(evt);
            }
        });
        jPanel4.add(desert4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));

        desertstext1.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        desertstext1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        desertstext1.setText("0");
        desertstext1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        desertstext1.setRequestFocusEnabled(false);
        desertstext1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                desertstext1ActionPerformed(evt);
            }
        });
        desertstext1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                desertstext1KeyTyped(evt);
            }
        });
        jPanel4.add(desertstext1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 80, 80, 20));

        desertstext2.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        desertstext2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        desertstext2.setText("0");
        desertstext2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        desertstext2.setRequestFocusEnabled(false);
        desertstext2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                desertstext2ActionPerformed(evt);
            }
        });
        desertstext2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                desertstext2KeyTyped(evt);
            }
        });
        jPanel4.add(desertstext2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 130, 80, 20));

        desertstext3.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        desertstext3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        desertstext3.setText("0");
        desertstext3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        desertstext3.setRequestFocusEnabled(false);
        desertstext3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                desertstext3ActionPerformed(evt);
            }
        });
        desertstext3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                desertstext3KeyTyped(evt);
            }
        });
        jPanel4.add(desertstext3, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 180, 80, 20));

        desertstext4.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        desertstext4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        desertstext4.setText("0");
        desertstext4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        desertstext4.setRequestFocusEnabled(false);
        desertstext4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                desertstext4ActionPerformed(evt);
            }
        });
        desertstext4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                desertstext4KeyTyped(evt);
            }
        });
        jPanel4.add(desertstext4, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 230, 80, 20));

        jPanel5.setBackground(new java.awt.Color(225, 225, 225));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        drinkslabel3.setFont(new java.awt.Font("Segoe Print", 1, 24)); // NOI18N
        drinkslabel3.setText("Drinks");
        jPanel5.add(drinkslabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 330, -1));

        drink13.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        drink13.setText("drink1");
        drink13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drink13ActionPerformed(evt);
            }
        });
        jPanel5.add(drink13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        drink14.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        drink14.setText("drink2");
        drink14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drink14ActionPerformed(evt);
            }
        });
        jPanel5.add(drink14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        drink15.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        drink15.setText("drink3");
        drink15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drink15ActionPerformed(evt);
            }
        });
        jPanel5.add(drink15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, -1));

        drink16.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        drink16.setText("drink4");
        drink16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drink16ActionPerformed(evt);
            }
        });
        jPanel5.add(drink16, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));

        dealtext21.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        dealtext21.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        dealtext21.setText("0");
        dealtext21.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        dealtext21.setRequestFocusEnabled(false);
        dealtext21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dealtext21ActionPerformed(evt);
            }
        });
        dealtext21.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dealtext21KeyTyped(evt);
            }
        });
        jPanel5.add(dealtext21, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 80, 80, 20));

        dealtext22.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        dealtext22.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        dealtext22.setText("0");
        dealtext22.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        dealtext22.setRequestFocusEnabled(false);
        dealtext22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dealtext22ActionPerformed(evt);
            }
        });
        dealtext22.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dealtext22KeyTyped(evt);
            }
        });
        jPanel5.add(dealtext22, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 130, 80, 20));

        dealtext23.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        dealtext23.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        dealtext23.setText("0");
        dealtext23.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        dealtext23.setRequestFocusEnabled(false);
        dealtext23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dealtext23ActionPerformed(evt);
            }
        });
        dealtext23.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dealtext23KeyTyped(evt);
            }
        });
        jPanel5.add(dealtext23, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 180, 80, 20));

        dealtext24.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        dealtext24.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        dealtext24.setText("0");
        dealtext24.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        dealtext24.setRequestFocusEnabled(false);
        dealtext24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dealtext24ActionPerformed(evt);
            }
        });
        dealtext24.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dealtext24KeyTyped(evt);
            }
        });
        jPanel5.add(dealtext24, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 230, 80, 20));

        jPanel4.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 110, 270, 280));

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 110, 290, 280));

        jPanel6.setBackground(new java.awt.Color(102, 213, 213));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        sublabel.setFont(new java.awt.Font("Segoe Print", 1, 24)); // NOI18N
        sublabel.setText("Fast Food/Desi Tarka/The Wonder wox");
        jPanel6.add(sublabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 250, 30));

        itemtext4.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        itemtext4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        itemtext4.setText("0");
        itemtext4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        itemtext4.setRequestFocusEnabled(false);
        itemtext4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemtext4ActionPerformed(evt);
            }
        });
        itemtext4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                itemtext4KeyTyped(evt);
            }
        });
        jPanel6.add(itemtext4, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 40, 80, 20));

        item4.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        item4.setText("item4");
        item4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                item4ActionPerformed(evt);
            }
        });
        jPanel6.add(item4, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 30, -1, -1));

        itemtext2.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        itemtext2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        itemtext2.setText("0");
        itemtext2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        itemtext2.setRequestFocusEnabled(false);
        itemtext2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemtext2ActionPerformed(evt);
            }
        });
        itemtext2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                itemtext2KeyTyped(evt);
            }
        });
        jPanel6.add(itemtext2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 120, 80, 20));

        item2.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        item2.setText("item2");
        item2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                item2ActionPerformed(evt);
            }
        });
        jPanel6.add(item2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, -1));

        itemtext3.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        itemtext3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        itemtext3.setText("0");
        itemtext3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        itemtext3.setRequestFocusEnabled(false);
        itemtext3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemtext3ActionPerformed(evt);
            }
        });
        itemtext3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                itemtext3KeyTyped(evt);
            }
        });
        jPanel6.add(itemtext3, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 160, 80, 20));

        item3.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        item3.setText("item3");
        item3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                item3ActionPerformed(evt);
            }
        });
        jPanel6.add(item3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, -1, -1));

        itemtext5.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        itemtext5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        itemtext5.setText("0");
        itemtext5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        itemtext5.setRequestFocusEnabled(false);
        itemtext5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemtext5ActionPerformed(evt);
            }
        });
        itemtext5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                itemtext5KeyTyped(evt);
            }
        });
        jPanel6.add(itemtext5, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 80, 80, 20));

        item5.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        item5.setText("item5");
        item5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                item5ActionPerformed(evt);
            }
        });
        jPanel6.add(item5, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 70, -1, -1));

        itemtext6.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        itemtext6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        itemtext6.setText("0");
        itemtext6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        itemtext6.setRequestFocusEnabled(false);
        itemtext6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemtext6ActionPerformed(evt);
            }
        });
        itemtext6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                itemtext6KeyTyped(evt);
            }
        });
        jPanel6.add(itemtext6, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 120, 80, 20));

        item6.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        item6.setText("item6");
        item6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                item6ActionPerformed(evt);
            }
        });
        jPanel6.add(item6, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 110, -1, -1));

        itemtext1.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        itemtext1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        itemtext1.setText("0");
        itemtext1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        itemtext1.setRequestFocusEnabled(false);
        itemtext1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemtext1ActionPerformed(evt);
            }
        });
        itemtext1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                itemtext1KeyTyped(evt);
            }
        });
        jPanel6.add(itemtext1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 80, 80, 20));

        item1.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        item1.setText("Item1");
        item1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                item1ActionPerformed(evt);
            }
        });
        jPanel6.add(item1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        item7.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        item7.setText("item7");
        item7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                item7ActionPerformed(evt);
            }
        });
        jPanel6.add(item7, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 150, -1, -1));

        itemtext7.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        itemtext7.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        itemtext7.setText("0");
        itemtext7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        itemtext7.setRequestFocusEnabled(false);
        itemtext7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemtext7ActionPerformed(evt);
            }
        });
        itemtext7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                itemtext7KeyTyped(evt);
            }
        });
        jPanel6.add(itemtext7, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 160, 80, 20));

        getContentPane().add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 400, 570, 210));

        jPanel7.setBackground(new java.awt.Color(225, 225, 225));
        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));

        Clear.setBackground(new java.awt.Color(0, 0, 0));
        Clear.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        Clear.setForeground(new java.awt.Color(255, 255, 255));
        Clear.setText("Clear");
        Clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearActionPerformed(evt);
            }
        });
        jPanel7.add(Clear);

        Cart.setBackground(new java.awt.Color(0, 0, 0));
        Cart.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        Cart.setForeground(new java.awt.Color(255, 255, 255));
        Cart.setText("Add to Cart");
        Cart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CartActionPerformed(evt);
            }
        });
        jPanel7.add(Cart);

        signout.setBackground(new java.awt.Color(0, 0, 0));
        signout.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        signout.setForeground(new java.awt.Color(255, 255, 255));
        signout.setText("Sign Out");
        signout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signoutActionPerformed(evt);
            }
        });
        jPanel7.add(signout);

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 616, 290, -1));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/menusssssssss.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 670));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void titlelabelFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_titlelabelFocusGained
        // TODO add your handling code here
    }//GEN-LAST:event_titlelabelFocusGained

    private void Product1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Product1ActionPerformed
        // TODO add your handling code here:
        if(Product1.isSelected()){
            counter++;
            labelsTexts.add(Product1.getText());
            dealtext1.setEnabled(true);
            dealtext1.requestFocus();
            dealtext1.setText("");
        }
        else{
             dealtext1.setEnabled(false);
             dealtext1.requestFocus(false);
             dealtext1.setText("");
        }
    }//GEN-LAST:event_Product1ActionPerformed

    private void dealtext1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dealtext1ActionPerformed
        // TODO add your handling code here:
        dealtext1.requestFocus(false);
    }//GEN-LAST:event_dealtext1ActionPerformed

    private void dealtext1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dealtext1KeyTyped
        // TODO add your handling code here:
        char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_dealtext1KeyTyped

    private void dealtext2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dealtext2ActionPerformed
        // TODO add your handling code here:
        dealtext2.requestFocus(false);
    }//GEN-LAST:event_dealtext2ActionPerformed

    private void dealtext2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dealtext2KeyTyped
        // TODO add your handling code here:
        char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_dealtext2KeyTyped

    private void dealtext3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dealtext3ActionPerformed
        // TODO add your handling code here:
        dealtext3.requestFocus(false);
    }//GEN-LAST:event_dealtext3ActionPerformed

    private void dealtext3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dealtext3KeyTyped
        // TODO add your handling code here:
        char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_dealtext3KeyTyped

    private void dealtext4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dealtext4ActionPerformed
        // TODO add your handling code here:
        dealtext4.requestFocus(false);
    }//GEN-LAST:event_dealtext4ActionPerformed

    private void dealtext4KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dealtext4KeyTyped
        // TODO add your handling code here:
        char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_dealtext4KeyTyped

    private void dealtext5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dealtext5ActionPerformed
        // TODO add your handling code here:
         dealtext5.requestFocus(false);
    }//GEN-LAST:event_dealtext5ActionPerformed

    private void dealtext5KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dealtext5KeyTyped
        // TODO add your handling code here:
        char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_dealtext5KeyTyped

    private void dealtext6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dealtext6ActionPerformed
        // TODO add your handling code here:
          dealtext6.requestFocus(false);
    }//GEN-LAST:event_dealtext6ActionPerformed

    private void dealtext6KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dealtext6KeyTyped
        // TODO add your handling code here:
        char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_dealtext6KeyTyped

    private void dealtext7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dealtext7ActionPerformed
        // TODO add your handling code here:
          dealtext7.requestFocus(false);
    }//GEN-LAST:event_dealtext7ActionPerformed

    private void dealtext7KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dealtext7KeyTyped
        // TODO add your handling code here:
        char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_dealtext7KeyTyped

    private void dealtext8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dealtext8ActionPerformed
        // TODO add your handling code here:
        dealtext8.requestFocus(false);
    }//GEN-LAST:event_dealtext8ActionPerformed

    private void dealtext8KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dealtext8KeyTyped
        // TODO add your handling code here:
        char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_dealtext8KeyTyped

    private void Product2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Product2ActionPerformed
        // TODO add your handling code here:
         if(Product2.isSelected()){
             counter++;
            dealtext2.setEnabled(true);
            dealtext2.requestFocus();
            dealtext2.setText("");
        }
        else{
             dealtext2.setEnabled(false);
             dealtext2.requestFocus(false);
             dealtext2.setText("");
        }
    }//GEN-LAST:event_Product2ActionPerformed

    private void Product3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Product3ActionPerformed
        // TODO add your handling code here:
         if(Product3.isSelected()){
             counter++;
            dealtext3.setEnabled(true);
            dealtext3.requestFocus();
            dealtext3.setText("");
        }
        else{
             dealtext3.setEnabled(false);
             dealtext3.requestFocus(false);
             dealtext3.setText("");
        }
    }//GEN-LAST:event_Product3ActionPerformed

    private void Product4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Product4ActionPerformed
        // TODO add your handling code here:
         if(Product4.isSelected()){
             counter++;
            dealtext4.setEnabled(true);
            dealtext4.requestFocus();
            dealtext4.setText("");
        }
        else{
             dealtext4.setEnabled(false);
             dealtext4.requestFocus(false);
             dealtext4.setText("");
        }
    }//GEN-LAST:event_Product4ActionPerformed

    private void Product5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Product5ActionPerformed
        // TODO add your handling code here:
         if(Product5.isSelected()){
             counter++;
            dealtext5.setEnabled(true);
            dealtext5.requestFocus();
            dealtext5.setText("");
        }
        else{
             dealtext5.setEnabled(false);
             dealtext5.requestFocus(false);
             dealtext5.setText("");
        }
    }//GEN-LAST:event_Product5ActionPerformed

    private void Product6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Product6ActionPerformed
        // TODO add your handling code here:
         if(Product6.isSelected()){
             counter++;
            dealtext6.setEnabled(true);
            dealtext6.requestFocus();
            dealtext6.setText("");
        }
        else{
             dealtext6.setEnabled(false);
             dealtext6.requestFocus(false);
             dealtext6.setText("");
        }
    }//GEN-LAST:event_Product6ActionPerformed

    private void Product7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Product7ActionPerformed
        // TODO add your handling code here:
         if(Product7.isSelected()){
             counter++;
            dealtext7.setEnabled(true);
            dealtext7.requestFocus();
            dealtext7.setText("");
        }
        else{
             dealtext7.setEnabled(false);
             dealtext7.requestFocus(false);
             dealtext7.setText("");
        }
    }//GEN-LAST:event_Product7ActionPerformed

    private void Product8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Product8ActionPerformed
        // TODO add your handling code here:
         if(Product8.isSelected()){
             counter++;
            dealtext8.setEnabled(true);
            dealtext8.requestFocus();
            dealtext8.setText("");
        }
        else{
             dealtext8.setEnabled(false);
             dealtext8.requestFocus(false);
             dealtext8.setText("");
        }
    }//GEN-LAST:event_Product8ActionPerformed

    private void drinktext4KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_drinktext4KeyTyped
        // TODO add your handling code here:
        char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_drinktext4KeyTyped

    private void drinktext4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drinktext4ActionPerformed
        // TODO add your handling code here:
        drinktext1.requestFocus(false);
    }//GEN-LAST:event_drinktext4ActionPerformed

    private void drinktext3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_drinktext3KeyTyped
        // TODO add your handling code here:
        char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_drinktext3KeyTyped

    private void drinktext3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drinktext3ActionPerformed
        // TODO add your handling code here:
        drinktext3.requestFocus(false);
    }//GEN-LAST:event_drinktext3ActionPerformed

    private void drinktext2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_drinktext2KeyTyped
        // TODO add your handling code here:
        char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_drinktext2KeyTyped

    private void drinktext2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drinktext2ActionPerformed
        // TODO add your handling code here:
        drinktext2.requestFocus(false);
    }//GEN-LAST:event_drinktext2ActionPerformed

    private void drinktext1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_drinktext1KeyTyped
        // TODO add your handling code here:
        char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_drinktext1KeyTyped

    private void drinktext1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drinktext1ActionPerformed
        // TODO add your handling code here:
        drinktext1.requestFocus(false);
    }//GEN-LAST:event_drinktext1ActionPerformed

    private void drink4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drink4ActionPerformed
        // TODO add your handling code here:
         if(drink4.isSelected()){
             counter++;
            drinktext4.setEnabled(true);
            drinktext4.requestFocus();
            drinktext4.setText("");
        }
        else{
             drinktext4.setEnabled(false);
             drinktext4.requestFocus(false);
             drinktext4.setText("");
        }
    }//GEN-LAST:event_drink4ActionPerformed

    private void drink3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drink3ActionPerformed
        // TODO add your handling code here:
         if(drink3.isSelected()){
             counter++;
            drinktext3.setEnabled(true);
            drinktext3.requestFocus();
            drinktext3.setText("");
        }
        else{
             drinktext3.setEnabled(false);
             drinktext3.requestFocus(false);
             drinktext3.setText("");
        }
    }//GEN-LAST:event_drink3ActionPerformed

    private void drink2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drink2ActionPerformed
        // TODO add your handling code here:
       if(drink2.isSelected()){
           counter++;
            drinktext2.setEnabled(true);
            drinktext2.requestFocus();
            drinktext2.setText("");
        }
        else{
             drinktext2.setEnabled(false);
             drinktext2.requestFocus(false);
             drinktext2.setText("");
        }
    }//GEN-LAST:event_drink2ActionPerformed

    private void drink1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drink1ActionPerformed
        // TODO add your handling code here:
          if(drink1.isSelected()){
              counter++;
            drinktext1.setEnabled(true);
            drinktext1.requestFocus();
            drinktext1.setText("");
        }
        else{
             drinktext1.setEnabled(false);
             drinktext1.requestFocus(false);
             drinktext1.setText("");
        }
    }//GEN-LAST:event_drink1ActionPerformed

    private void drink5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drink5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_drink5ActionPerformed

    private void drink6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drink6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_drink6ActionPerformed

    private void drink7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drink7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_drink7ActionPerformed

    private void drink8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drink8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_drink8ActionPerformed

    private void dealtext13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dealtext13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dealtext13ActionPerformed

    private void dealtext13KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dealtext13KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_dealtext13KeyTyped

    private void dealtext14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dealtext14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dealtext14ActionPerformed

    private void dealtext14KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dealtext14KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_dealtext14KeyTyped

    private void dealtext15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dealtext15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dealtext15ActionPerformed

    private void dealtext15KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dealtext15KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_dealtext15KeyTyped

    private void dealtext16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dealtext16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dealtext16ActionPerformed

    private void dealtext16KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dealtext16KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_dealtext16KeyTyped

    private void desert1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_desert1ActionPerformed
        // TODO add your handling code here:
        if(desert1.isSelected()){
            counter++;
            desertstext1.setEnabled(true);
            desertstext1.requestFocus();
            desertstext1.setText("");
        }
        else{
             desertstext1.setEnabled(false);
             desertstext1.requestFocus(false);
             desertstext1.setText("");
        }
    }//GEN-LAST:event_desert1ActionPerformed

    private void desert2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_desert2ActionPerformed
        // TODO add your handling code here:
         if(desert2.isSelected()){
             counter++;
            desertstext2.setEnabled(true);
            desertstext2.requestFocus();
            desertstext2.setText("");
        }
        else{
             desertstext2.setEnabled(false);
             desertstext2.requestFocus(false);
             desertstext2.setText("");
        }
    }//GEN-LAST:event_desert2ActionPerformed

    private void desert3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_desert3ActionPerformed
        // TODO add your handling code here:
          if(desert3.isSelected()){
              counter++;
            desertstext3.setEnabled(true);
            desertstext3.requestFocus();
            desertstext3.setText("");
        }
        else{
             desertstext3.setEnabled(false);
             desertstext3.requestFocus(false);
             desertstext3.setText("");
        }
    }//GEN-LAST:event_desert3ActionPerformed

    private void desert4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_desert4ActionPerformed
        // TODO add your handling code here:
          if(desert4.isSelected()){
              counter++;
            desertstext4.setEnabled(true);
            desertstext4.requestFocus();
            desertstext4.setText("");
        }
        else{
             desertstext4.setEnabled(false);
             desertstext4.requestFocus(false);
             desertstext4.setText("");
        }
    }//GEN-LAST:event_desert4ActionPerformed

    private void desertstext1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_desertstext1ActionPerformed
        // TODO add your handling code here:
        desertstext1.requestFocus(false);
    }//GEN-LAST:event_desertstext1ActionPerformed

    private void desertstext1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_desertstext1KeyTyped
        // TODO add your handling code here:
         char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_desertstext1KeyTyped

    private void desertstext2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_desertstext2ActionPerformed
        // TODO add your handling code here:
         desertstext2.requestFocus(false);
    }//GEN-LAST:event_desertstext2ActionPerformed

    private void desertstext2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_desertstext2KeyTyped
        // TODO add your handling code here:
         char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_desertstext2KeyTyped

    private void desertstext3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_desertstext3ActionPerformed
        // TODO add your handling code here:
         desertstext3.requestFocus(false);
    }//GEN-LAST:event_desertstext3ActionPerformed

    private void desertstext3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_desertstext3KeyTyped
        // TODO add your handling code here:
         char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_desertstext3KeyTyped

    private void desertstext4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_desertstext4ActionPerformed
        // TODO add your handling code here:
         desertstext4.requestFocus(false);
    }//GEN-LAST:event_desertstext4ActionPerformed

    private void desertstext4KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_desertstext4KeyTyped
        // TODO add your handling code here:
         char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_desertstext4KeyTyped

    private void drink13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drink13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_drink13ActionPerformed

    private void drink14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drink14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_drink14ActionPerformed

    private void drink15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drink15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_drink15ActionPerformed

    private void drink16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drink16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_drink16ActionPerformed

    private void dealtext21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dealtext21ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dealtext21ActionPerformed

    private void dealtext21KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dealtext21KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_dealtext21KeyTyped

    private void dealtext22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dealtext22ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dealtext22ActionPerformed

    private void dealtext22KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dealtext22KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_dealtext22KeyTyped

    private void dealtext23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dealtext23ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dealtext23ActionPerformed

    private void dealtext23KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dealtext23KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_dealtext23KeyTyped

    private void dealtext24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dealtext24ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dealtext24ActionPerformed

    private void dealtext24KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dealtext24KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_dealtext24KeyTyped

    private void itemtext4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemtext4ActionPerformed
        // TODO add your handling code here:
        itemtext4.requestFocus(false);
    }//GEN-LAST:event_itemtext4ActionPerformed

    private void itemtext4KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itemtext4KeyTyped
        // TODO add your handling code here:
         char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_itemtext4KeyTyped

    private void item4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_item4ActionPerformed
        // TODO add your handling code here:
        if(item4.isSelected()){
            counter++;
            itemtext4.setEnabled(true);
            itemtext4.requestFocus();
            itemtext4.setText("");
        }
        else{
             itemtext4.setEnabled(false);
             itemtext4.requestFocus(false);
             itemtext4.setText("");
        }
    }//GEN-LAST:event_item4ActionPerformed

    private void itemtext2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemtext2ActionPerformed
        // TODO add your handling code here:
        itemtext2.requestFocus(false);
    }//GEN-LAST:event_itemtext2ActionPerformed

    private void itemtext2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itemtext2KeyTyped
        // TODO add your handling code here:
         char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_itemtext2KeyTyped

    private void item2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_item2ActionPerformed
        // TODO add your handling code here:
       if(item2.isSelected()){
           counter++;
            itemtext2.setEnabled(true);
            itemtext2.requestFocus();
            itemtext2.setText("");
        }
        else{
             itemtext2.setEnabled(false);
             itemtext2.requestFocus(false);
             itemtext2.setText("");
        }
    }//GEN-LAST:event_item2ActionPerformed

    private void itemtext3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemtext3ActionPerformed
        // TODO add your handling code here:
        itemtext3.requestFocus(false);
    }//GEN-LAST:event_itemtext3ActionPerformed

    private void itemtext3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itemtext3KeyTyped
        // TODO add your handling code here:
         char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_itemtext3KeyTyped

    private void item3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_item3ActionPerformed
        // TODO add your handling code here:
       if(item3.isSelected()){
           counter++;
            itemtext3.setEnabled(true);
            itemtext3.requestFocus();
            itemtext3.setText("");
        }
        else{
             itemtext3.setEnabled(false);
             itemtext3.requestFocus(false);
             itemtext3.setText("");
        }
    }//GEN-LAST:event_item3ActionPerformed

    private void itemtext5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemtext5ActionPerformed
        // TODO add your handling code here:
        itemtext5.requestFocus(false);
    }//GEN-LAST:event_itemtext5ActionPerformed

    private void itemtext5KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itemtext5KeyTyped
        // TODO add your handling code here:
         char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_itemtext5KeyTyped

    private void item5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_item5ActionPerformed
        // TODO add your handling code here:
        if(item5.isSelected()){
            counter++;
            itemtext5.setEnabled(true);
            itemtext5.requestFocus();
            itemtext5.setText("");
        }
        else{
             itemtext5.setEnabled(false);
             itemtext5.requestFocus(false);
             itemtext5.setText("");
        }
    }//GEN-LAST:event_item5ActionPerformed

    private void itemtext6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemtext6ActionPerformed
        // TODO add your handling code here:
        itemtext6.requestFocus(false);
    }//GEN-LAST:event_itemtext6ActionPerformed

    private void itemtext6KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itemtext6KeyTyped
        // TODO add your handling code here:
         char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_itemtext6KeyTyped

    private void item6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_item6ActionPerformed
        // TODO add your handling code here:
        if(item6.isSelected()){
            counter++;
            itemtext6.setEnabled(true);
            itemtext6.requestFocus();
            itemtext6.setText("");
        }
        else{
             itemtext6.setEnabled(false);
             itemtext6.requestFocus(false);
             itemtext6.setText("");
        }
    }//GEN-LAST:event_item6ActionPerformed

    private void itemtext1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemtext1ActionPerformed
        // TODO add your handling code here:
         itemtext1.requestFocus(false);
    }//GEN-LAST:event_itemtext1ActionPerformed

    private void itemtext1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itemtext1KeyTyped
        // TODO add your handling code here:
         char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_itemtext1KeyTyped

    private void item1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_item1ActionPerformed
        // TODO add your handling code here:
        if(item1.isSelected()){
            counter++;
            itemtext1.setEnabled(true);
            itemtext1.requestFocus();
            itemtext1.setText("");
        }
        else{
             itemtext1.setEnabled(false);
             itemtext1.requestFocus(false);
             itemtext1.setText("");
        }
    }//GEN-LAST:event_item1ActionPerformed

    private void item7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_item7ActionPerformed
        // TODO add your handling code here:
       if(item7.isSelected()){
           counter++;
            itemtext7.setEnabled(true);
            itemtext7.requestFocus();
            itemtext7.setText("");
        }
        else{
             itemtext7.setEnabled(false);
             itemtext7.requestFocus(false);
             itemtext7.setText("");
        }
    }//GEN-LAST:event_item7ActionPerformed

    private void itemtext7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemtext7ActionPerformed
        // TODO add your handling code here:
        itemtext7.requestFocus(false);
    }//GEN-LAST:event_itemtext7ActionPerformed

    private void itemtext7KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_itemtext7KeyTyped
        // TODO add your handling code here:
         char iNumber=evt.getKeyChar();
        if(!(Character.isDigit(iNumber)) || (iNumber == KeyEvent.VK_BACK_SPACE) || (iNumber == KeyEvent.VK_DELETE)){
            evt.consume();
        }
    }//GEN-LAST:event_itemtext7KeyTyped

    private void ClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearActionPerformed
        // TODO add your handling code here:
        dealtext1.setText("0");
        dealtext2.setText("0");
        dealtext3.setText("0");
        dealtext4.setText("0");
        dealtext5.setText("0");
        dealtext6.setText("0");
        dealtext7.setText("0");
        dealtext8.setText("0");
        drinktext1.setText("0");
        drinktext2.setText("0");
        drinktext3.setText("0");
        drinktext4.setText("0");
        desertstext1.setText("0");
        desertstext2.setText("0");
        desertstext3.setText("0");
        desertstext4.setText("0");
        itemtext1.setText("0");
        itemtext2.setText("0");
        itemtext3.setText("0");
        itemtext4.setText("0");
        itemtext5.setText("0");
        itemtext6.setText("0");
        itemtext7.setText("0");
        //========================================//
        Product1.setSelected(false);
        Product2.setSelected(false);
        Product3.setSelected(false);
        Product4.setSelected(false);
        Product5.setSelected(false);
        Product6.setSelected(false);
        Product7.setSelected(false);
        Product8.setSelected(false);
        drink1.setSelected(false);
        drink2.setSelected(false);
        drink3.setSelected(false);
        drink4.setSelected(false);
        desert1.setSelected(false);
        desert2.setSelected(false);
        desert3.setSelected(false);
        desert4.setSelected(false);
        item1.setSelected(false);
        item2.setSelected(false);
        item3.setSelected(false);
        item4.setSelected(false);
        item5.setSelected(false);
        item6.setSelected(false);
        item7.setSelected(false);
        

    }//GEN-LAST:event_ClearActionPerformed

    private void CartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CartActionPerformed
        // TODO add your handling code here:
             Burger_Cart b_cart=new Burger_Cart(labelsTexts);
         b_cart.setVisible(true);
         this.setVisible(false);  

    }//GEN-LAST:event_CartActionPerformed
private JFrame frame;
    private void signoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signoutActionPerformed
        // TODO add your handling code here:
        frame=new JFrame("Sign Out");
        if(JOptionPane.showConfirmDialog(frame, "Confirm if You Want to Sign Out ?", "Food Ordering System", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION){
         Login log=new Login();
        log.setVisible(true);
        this.setVisible(false);   
        }
    }//GEN-LAST:event_signoutActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Res_Menus.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Res_Menus.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Res_Menus.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Res_Menus.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Res_Menus().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cart;
    private javax.swing.JButton Clear;
    public javax.swing.JCheckBox Product1;
    public javax.swing.JCheckBox Product2;
    public javax.swing.JCheckBox Product3;
    public javax.swing.JCheckBox Product4;
    public javax.swing.JCheckBox Product5;
    public javax.swing.JCheckBox Product6;
    public javax.swing.JCheckBox Product7;
    public javax.swing.JCheckBox Product8;
    public javax.swing.JLabel dealslabel;
    public javax.swing.JTextField dealtext1;
    public javax.swing.JTextField dealtext13;
    public javax.swing.JTextField dealtext14;
    public javax.swing.JTextField dealtext15;
    public javax.swing.JTextField dealtext16;
    public javax.swing.JTextField dealtext2;
    public javax.swing.JTextField dealtext21;
    public javax.swing.JTextField dealtext22;
    public javax.swing.JTextField dealtext23;
    public javax.swing.JTextField dealtext24;
    public javax.swing.JTextField dealtext3;
    public javax.swing.JTextField dealtext4;
    public javax.swing.JTextField dealtext5;
    public javax.swing.JTextField dealtext6;
    public javax.swing.JTextField dealtext7;
    public javax.swing.JTextField dealtext8;
    public javax.swing.JCheckBox desert1;
    public javax.swing.JCheckBox desert2;
    public javax.swing.JCheckBox desert3;
    public javax.swing.JCheckBox desert4;
    public javax.swing.JLabel desertslabel;
    public javax.swing.JTextField desertstext1;
    public javax.swing.JTextField desertstext2;
    public javax.swing.JTextField desertstext3;
    public javax.swing.JTextField desertstext4;
    public javax.swing.JCheckBox drink1;
    public javax.swing.JCheckBox drink13;
    public javax.swing.JCheckBox drink14;
    public javax.swing.JCheckBox drink15;
    public javax.swing.JCheckBox drink16;
    public javax.swing.JCheckBox drink2;
    public javax.swing.JCheckBox drink3;
    public javax.swing.JCheckBox drink4;
    public javax.swing.JCheckBox drink5;
    public javax.swing.JCheckBox drink6;
    public javax.swing.JCheckBox drink7;
    public javax.swing.JCheckBox drink8;
    public javax.swing.JLabel drinkslabel;
    public javax.swing.JLabel drinkslabel1;
    public javax.swing.JLabel drinkslabel3;
    public javax.swing.JTextField drinktext1;
    public javax.swing.JTextField drinktext2;
    public javax.swing.JTextField drinktext3;
    public javax.swing.JTextField drinktext4;
    public javax.swing.JCheckBox item1;
    public javax.swing.JCheckBox item2;
    public javax.swing.JCheckBox item3;
    public javax.swing.JCheckBox item4;
    public javax.swing.JCheckBox item5;
    public javax.swing.JCheckBox item6;
    public javax.swing.JCheckBox item7;
    public javax.swing.JTextField itemtext1;
    public javax.swing.JTextField itemtext2;
    public javax.swing.JTextField itemtext3;
    public javax.swing.JTextField itemtext4;
    public javax.swing.JTextField itemtext5;
    public javax.swing.JTextField itemtext6;
    public javax.swing.JTextField itemtext7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JButton signout;
    public javax.swing.JLabel sublabel;
    public javax.swing.JLabel titlelabel;
    // End of variables declaration//GEN-END:variables
}
