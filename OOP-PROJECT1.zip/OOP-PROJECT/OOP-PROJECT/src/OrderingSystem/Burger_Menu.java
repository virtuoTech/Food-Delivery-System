
package OrderingSystem;

public class Burger_Menu{
public String main_title,sub_title,box_title;

public String SetTitleBurger(){
       main_title="Burger O' Clock Menu";
return main_title; 
}
    public String SubTitle_1(){
       sub_title="Burger O' Clock Burgers";
return sub_title; 
}
    public String SetBoxTitle_1(){
       box_title="Beef Burger";
return box_title; 
}
     public String SetBoxTitle_2(){
       box_title="Extra Crisp Burger";
return box_title; 
}
      public String SetBoxTitle_3(){
       box_title="Beef Veggie Burger";
return box_title; 
}
       public String SetBoxTitle_4(){
       box_title="Beef Cheese Burger";
return box_title; 
}
        public String SetBoxTitle_5(){
       box_title="Fire Bird Burger";
return box_title; 
}
         public String SetBoxTitle_6(){
       box_title="Chicken Burger";
return box_title; 
}
          public String SetBoxTitle_7(){
       box_title="Beef Smoky Burger";
return box_title; 
}
           public String SetBoxTitle_8(){
       box_title="Belt Buster Burger";
return box_title; 
}
           public String SubTitle_2(){
       sub_title="Bevreges";
return sub_title; 
}
           public String SetBoxTitle_9(){
       box_title="Water";
return box_title; 
}
           public String SetBoxTitle_10(){
       box_title="Pepsi";
return box_title; 
}
           public String SetBoxTitle_11(){
       box_title="Sprite";
return box_title; 
}
           public String SetBoxTitle_12(){
       box_title="Fanta";
return box_title; 
}
           public String SubTitle_3(){
       sub_title="Gourmet Fries";
return sub_title; 
}
      public String SetBoxTitle_13(){
       box_title="Wild Fries";
return box_title; 
}
 public String SetBoxTitle_14(){
       box_title="Reg. Fires";
return box_title; 
}
  public String SetBoxTitle_15(){
       box_title="Mayo Fries";
return box_title; 
}
   public String SetBoxTitle_16(){
       box_title="Chilli Fries";
return box_title; 
}
    public String SubTitle_4(){
       sub_title="Appetizers";
return sub_title; 
}
    public String SetBoxTitle_17(){
       box_title="Peri Bites";
return box_title; 
}
    public String SetBoxTitle_18(){
       box_title="Cheese Sticks";
return box_title; 
}
    public String SetBoxTitle_19(){
       box_title="Finger Sticks";
return box_title; 
}
    public String SetBoxTitle_20(){
       box_title="Red Wings";
return box_title; 
}
    public String SetBoxTitle_21(){
       box_title="Hot Wings";
return box_title; 
}
    public String SetBoxTitle_22(){
       box_title="BBQ Wings";
return box_title; 
}
    public String SetBoxTitle_23(){
       box_title="Smoky Wings";
return box_title; 
}
    
}