package OrderingSystem;

public class KababJeesMenu {

    public String main_title,sub_title,box_title;
    
public String SetTitleBurger(){
       main_title="Kabab Jees Menu";
return main_title; 
}
    public String SubTitle_1(){
       sub_title="Rice/Kababs";
return sub_title; 
}
    public String SetBoxTitle_1(){
       box_title="C.Fried Rice";
return box_title; 
}
     public String SetBoxTitle_2(){
       box_title="Egg Fried Rice";
return box_title; 
}
      public String SetBoxTitle_3(){
       box_title="Veg.Fried Rice";
return box_title; 
}
       public String SetBoxTitle_4(){
       box_title="C.Masala Rice";
return box_title; 
}
        public String SetBoxTitle_5(){
       box_title="Gola Kabab";
return box_title; 
}
         public String SetBoxTitle_6(){
       box_title="Mutton Kabab";
return box_title; 
}
          public String SetBoxTitle_7(){
       box_title="Chicken Kabab";
return box_title; 
}
           public String SetBoxTitle_8(){
       box_title="Seekh Kabab";
return box_title; 
}
           public String SubTitle_2(){
       sub_title="Bevreges";
return sub_title; 
}
           public String SetBoxTitle_9(){
       box_title="Water";
return box_title; 
}
           public String SetBoxTitle_10(){
       box_title="Soft Drink";
return box_title; 
}
           public String SetBoxTitle_11(){
       box_title="Lassi";
return box_title; 
}
           public String SetBoxTitle_12(){
       box_title="Fresh Lime";
return box_title; 
}
           public String SubTitle_3(){
       sub_title="Desi Tarka";
return sub_title; 
}
      public String SetBoxTitle_13(){
       box_title="C.Handi";
return box_title; 
}
 public String SetBoxTitle_14(){
       box_title="C.Karhai";
return box_title; 
}
  public String SetBoxTitle_15(){
       box_title="Kata Kat";
return box_title; 
}
   public String SetBoxTitle_16(){
       box_title="Tawa Masala";
return box_title; 
}
    public String SubTitle_4(){
       sub_title="Hot Tandoor";
return sub_title; 
}
    public String SetBoxTitle_17(){
       box_title="Plain Naan";
return box_title; 
}
    public String SetBoxTitle_18(){
       box_title="Garlic Naan";
return box_title; 
}
    public String SetBoxTitle_19(){
       box_title="Roghni Naan";
return box_title; 
}
    public String SetBoxTitle_20(){
       box_title="Wheat Naan";
return box_title; 
}
    public String SetBoxTitle_21(){
       box_title="Chapatti";
return box_title; 
}
    public String SetBoxTitle_22(){
       box_title="Puri";
return box_title; 
}
    public String SetBoxTitle_23(){
       box_title="Cheese Naan";
return box_title; 
}  
    
}
