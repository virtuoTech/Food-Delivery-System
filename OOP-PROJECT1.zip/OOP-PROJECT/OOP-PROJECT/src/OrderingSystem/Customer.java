package OrderingSystem;

public class Customer extends Customer_Info {
private char Id;
protected String Name,Addess,P_No,Email;

public void MakePayment(){
    

}
public void AddtoCart(){
    
}
public void DeletefromCart(){
    
}
}
