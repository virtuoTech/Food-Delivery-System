
package AdminPanel;

import DefaultPanel.ConnectionToDb;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class AdminAccess extends javax.swing.JFrame {
ConnectionToDb con_obj=new ConnectionToDb();
AdminClass log;
    public AdminAccess() {
        this.log = new AdminClass();
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane2 = new javax.swing.JTabbedPane();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        aname = new javax.swing.JTextField();
        apin = new javax.swing.JPasswordField();
        Create = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        apinconfirm = new javax.swing.JPasswordField();
        signout = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        delete = new javax.swing.JButton();
        search = new javax.swing.JButton();
        txtuserid = new javax.swing.JTextField();
        txtuname = new javax.swing.JTextField();
        txtupin = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTabbedPane2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jTabbedPane1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 0, 0));
        jLabel3.setText("Enter Admin Name :");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(153, 0, 0));
        jLabel4.setText("Enter Admin Pin : ");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, -1, -1));

        aname.setFont(new java.awt.Font("Yu Gothic UI", 0, 14)); // NOI18N
        jPanel1.add(aname, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 30, 190, -1));

        apin.setFont(new java.awt.Font("Yu Gothic UI", 0, 14)); // NOI18N
        apin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apinActionPerformed(evt);
            }
        });
        jPanel1.add(apin, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 70, 190, 30));

        Create.setBackground(new java.awt.Color(204, 204, 255));
        Create.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        Create.setText("Add Admin");
        Create.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CreateActionPerformed(evt);
            }
        });
        jPanel1.add(Create, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 170, 140, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 0, 0));
        jLabel5.setText("Confirm Admin Pin : ");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, -1, -1));

        apinconfirm.setFont(new java.awt.Font("Yu Gothic UI", 0, 14)); // NOI18N
        apinconfirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apinconfirmActionPerformed(evt);
            }
        });
        jPanel1.add(apinconfirm, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 110, 190, 30));

        signout.setBackground(new java.awt.Color(204, 204, 255));
        signout.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        signout.setText("Sign Out");
        signout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signoutActionPerformed(evt);
            }
        });
        jPanel1.add(signout, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 170, 140, 30));

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("jLabel2");
        jLabel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 470, 240));

        jTabbedPane1.addTab("Add", jPanel1);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        delete.setFont(new java.awt.Font("Segoe Print", 0, 12)); // NOI18N
        delete.setText("Delete User");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        jPanel2.add(delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 160, 110, 30));

        search.setText("Search");
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        jPanel2.add(search, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 160, 100, 30));
        jPanel2.add(txtuserid, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 60, 130, 20));
        jPanel2.add(txtuname, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 90, 130, 20));
        jPanel2.add(txtupin, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 120, 130, 20));

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Admin Id");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 60, 110, 20));

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Admin Name");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 90, 130, 20));

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Admin Pin");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 120, 110, 20));

        jLabel1.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
                jLabel1AncestorMoved(evt);
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-140, 0, 590, 240));

        jTabbedPane1.addTab("Remove", jPanel2);

        jTabbedPane2.addTab("Admin", jTabbedPane1);

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jTabbedPane2.addTab("Record", jPanel3);

        getContentPane().add(jTabbedPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 460, 310));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1AncestorMoved(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jLabel1AncestorMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel1AncestorMoved

    private void apinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apinActionPerformed

    private void CreateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CreateActionPerformed
        // TODO add your handling code here:
        con_obj.EstablishConnection_1();
        AdminClass Login;
    Login = new AdminClass();
        String AN=aname.getText();
        String AP;
    AP = apin.getText();
        boolean b=Login.CreateUser(AN, AP);
        if(b){
            JOptionPane.showMessageDialog(null, "Account Registered");
        }
        else{
             JOptionPane.showMessageDialog(null, "Error");
        }
        aname.setText("");
        apin.setText("");
        apinconfirm.setText("");
       
        
        
    }//GEN-LAST:event_CreateActionPerformed

    private void apinconfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apinconfirmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apinconfirmActionPerformed

    private void signoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signoutActionPerformed
        // TODO add your handling code here:
        JFrame frame = new JFrame("Sign Out");
        if(JOptionPane.showConfirmDialog(frame, "Confirm if You Want to Sign Out ?", "Food Ordering System", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION){
            Login_admin login;
            login = new Login_admin();
            login.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_signoutActionPerformed

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        // TODO add your handling code here:
        int id= Integer.parseInt(txtuserid.getText());
        boolean b;
    b = log.RequestUser(id);
        if(b){
            txtuname.setText(log.name);
            txtupin.setText(log.pwsd);
        }
        else{
            JOptionPane.showConfirmDialog(null, "Error");
        }
    }//GEN-LAST:event_searchActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
            // TODO add your handling code here:
        int id=Integer.parseInt(txtuserid.getText());
        boolean b;
    b = log.DeleteUser(id);
        if(b){
            JOptionPane.showConfirmDialog(null, "RecordDeleted");
        }
        else{
            JOptionPane.showConfirmDialog(null, "Error");
        }
       txtuserid.setText("");
       txtupin.setText("");
       txtuname.setText("");
      
    }//GEN-LAST:event_deleteActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminAccess.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminAccess.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminAccess.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminAccess.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new AdminAccess().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Create;
    private javax.swing.JTextField aname;
    private javax.swing.JPasswordField apin;
    private javax.swing.JPasswordField apinconfirm;
    private javax.swing.JButton delete;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JButton search;
    private javax.swing.JButton signout;
    private javax.swing.JTextField txtuname;
    private javax.swing.JTextField txtupin;
    private javax.swing.JTextField txtuserid;
    // End of variables declaration//GEN-END:variables
}
