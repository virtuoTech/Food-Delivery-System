package AdminPanel;

import DefaultPanel.ConnectionToDb;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class AdminClass {
ConnectionToDb con=new ConnectionToDb();
Connection con_obj=con.EstablishConnection_1();
Statement stmt=null;
PreparedStatement pstmt=null;
ResultSet res=null;
String name,pwsd;
    
   public boolean CreateUser(String aname,String apin){
    boolean b=false;
    
    String sql="insert into AdminDetails(AdminName,AdminPin)values('"+aname+"','"+apin+"')";
    try{
        stmt=con_obj.createStatement();
        int ress;
        ress = stmt.executeUpdate(sql);
        if(ress>0){
           b=true;
           //JOptionPane.showMessageDialog(null, "Insterted");
           
        }
        else{
           b=false;
           // JOptionPane.showMessageDialog(null, "Error");
           
        }
    }
    catch(SQLException ex){
        JOptionPane.showMessageDialog(null, ex);
    }
    return b;
}
   
   public boolean RequestUser(int id){
    String LoginString="select * from AdminDetails where ID='"+id+"'";
    boolean b=false;
    try{
        pstmt=con_obj.prepareStatement(LoginString);
        res=pstmt.executeQuery();
        while(res.next()){
            name=res.getString("UserName");
            pwsd=res.getString("UserPass");
            b=true;
            
        }
        
    }
    catch(SQLException ex){
        JOptionPane.showMessageDialog(null, ex);
    }
    return b;
}
   
   
   public boolean DeleteUser(int id){
    boolean b=false;
    
    String sql="delete from AdminDetails where ID='"+id+"'";
    try{
        stmt=con_obj.createStatement();
        int res=stmt.executeUpdate(sql);
        if(res>0){
           b=true;
           //JOptionPane.showMessageDialog(null, "Deleted");
           
        }
        else{
           b=false;
           // JOptionPane.showMessageDialog(null, "Error");
           
        }
    }
    catch(SQLException ex){
        JOptionPane.showMessageDialog(null, ex);
    }
    return b;
}
 
    
    
}
