package DefaultPanel;


import AdminPanel.Login_admin;
import OrderingSystem.HomePage;
import javax.swing.JOptionPane;

public class Login extends javax.swing.JFrame {
ConnectionToDb con_obj=new ConnectionToDb();
   
    public Login() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    String UE="durraiznaqvi@gmail.com";
    String UP="1234";
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        uemail = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        login = new javax.swing.JButton();
        create = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        upin = new javax.swing.JPasswordField();
        forgetpass = new javax.swing.JButton();
        login_admin = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        jLabel4.setText("jLabel4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        uemail.setFont(new java.awt.Font("Yu Gothic UI", 0, 14)); // NOI18N
        uemail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uemailActionPerformed(evt);
            }
        });
        getContentPane().add(uemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 310, 190, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 0, 0));
        jLabel1.setText("Email ID :  ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 310, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 0, 0));
        jLabel2.setText("Pin : ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 350, -1, -1));

        login.setBackground(new java.awt.Color(255, 153, 0));
        login.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        login.setText("Login ");
        login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginActionPerformed(evt);
            }
        });
        getContentPane().add(login, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 330, 140, 30));

        create.setBackground(new java.awt.Color(255, 153, 0));
        create.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        create.setText("Create Account");
        create.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createActionPerformed(evt);
            }
        });
        getContentPane().add(create, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 590, 140, 30));

        jLabel3.setFont(new java.awt.Font("Segoe Print", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 0, 0));
        jLabel3.setText("Welcome To Food Ordering System ");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 470, 60));

        upin.setFont(new java.awt.Font("Yu Gothic UI", 0, 14)); // NOI18N
        upin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                upinActionPerformed(evt);
            }
        });
        getContentPane().add(upin, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 350, 190, 30));

        forgetpass.setBackground(new java.awt.Color(255, 153, 0));
        forgetpass.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        forgetpass.setText("Forget Pin ?");
        forgetpass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                forgetpassActionPerformed(evt);
            }
        });
        getContentPane().add(forgetpass, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 630, 140, 30));

        login_admin.setBackground(new java.awt.Color(255, 153, 0));
        login_admin.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        login_admin.setText("Login as Admin");
        login_admin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                login_adminActionPerformed(evt);
            }
        });
        getContentPane().add(login_admin, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 550, 140, 30));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/bbb.jpg"))); // NOI18N
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -160, 600, 1020));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginActionPerformed
        // TODO add your handling code here:
        con_obj.EstablishConnection_1();
        String getUE=uemail.getText();
        String getUP=upin.getText();
        
        CRUD_Functions log=new CRUD_Functions();
        boolean b = (getUE.equals(UE) && getUP.equals(UP));
        
        if(b){
            HomePage hp=new HomePage();
            hp.setVisible(true);
            this.setVisible(false);
            JOptionPane.showMessageDialog(null, "Logged In");
        }
        else{
             JOptionPane.showMessageDialog(null, "Logged Denied");
        }
    }//GEN-LAST:event_loginActionPerformed

    private void createActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createActionPerformed
        // TODO add your handling code here:
        CreateAccount ca=new CreateAccount();
        ca.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_createActionPerformed

    private void forgetpassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_forgetpassActionPerformed
        // TODO add your handling code here:
        Forgetpin fp=new Forgetpin();
        fp.setVisible(true);
        this.setVisible(false);
        
    }//GEN-LAST:event_forgetpassActionPerformed

    private void upinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_upinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_upinActionPerformed

    private void login_adminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_login_adminActionPerformed
        // TODO add your handling code here:
        Login_admin logA=new Login_admin();
        logA.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_login_adminActionPerformed

    private void uemailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uemailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_uemailActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton create;
    private javax.swing.JButton forgetpass;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JButton login;
    private javax.swing.JButton login_admin;
    private javax.swing.JTextField uemail;
    private javax.swing.JPasswordField upin;
    // End of variables declaration//GEN-END:variables
}
