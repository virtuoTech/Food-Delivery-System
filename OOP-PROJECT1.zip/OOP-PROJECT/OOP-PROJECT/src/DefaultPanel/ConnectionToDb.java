package DefaultPanel;

import java.sql.*;
import javax.swing.JOptionPane;
public class ConnectionToDb{
    Connection con1=null;
    Connection con2=null;
    public Connection EstablishConnection_1(){
    try{
        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        con1=(Connection) DriverManager.getConnection("jdbc:ucanaccess://src\\Records\\Login.accdb");
        //JOptionPane.showMessageDialog(null, "Connected");
    }
    catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex);
    }
    return con1;  
    }
    public Connection EstablishConnection_2(){
    try{
        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        con2=(Connection) DriverManager.getConnection("jdbc:ucanaccess://src\\Records\\DBFoodOrder.accdb");
        //JOptionPane.showMessageDialog(null, "Connected");
    }
    catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex);
    }
    return con2;  
    }

}