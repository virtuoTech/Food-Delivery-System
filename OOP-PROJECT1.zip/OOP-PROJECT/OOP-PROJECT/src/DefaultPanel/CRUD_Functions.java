package DefaultPanel;

import java.sql.*;
import javax.swing.JOptionPane;
public class CRUD_Functions {
ConnectionToDb con=new ConnectionToDb();
Connection con_obj=con.EstablishConnection_1();
Statement stmt=null;
PreparedStatement pstmt=null;
ResultSet res=null;
String name,pwsd;
public boolean LoginUser(String uemail,String upin){
    String LoginString="Select * from loginDetails where Email='"+uemail+"'and Pin='"+upin+"'";
    boolean b;  
            try{
                pstmt=con_obj.prepareStatement(LoginString);
                res=pstmt.executeQuery();
                if(res.next()){
                    b=true;
                }
                else{
                    b=false;
                }
            }
            catch(Exception ex){
                JOptionPane.showMessageDialog(null, uemail);
                b=false;
            }
            return b;
}
public boolean LoginAdmin(String Aname,String Apin){
    String LoginString="Select * from AdminDetails where AdminName='"+Aname+"'and AdminPin='"+Apin+"'";
    boolean b;  
            try{
                pstmt=con_obj.prepareStatement(LoginString);
                res=pstmt.executeQuery();
                if(res.next()){
                    b=true;
                }
                else{
                    b=false;
                }
            }
            catch(Exception ex){
                JOptionPane.showMessageDialog(null, Aname);
                b=false;
            }
            return b;
}

public boolean CreateUser(String uemail,String upin){
    boolean b=false;
    
    String sql="insert into loginDetails(Email,Pin)values('"+uemail+"','"+upin+"')";
    try{
        stmt=con_obj.createStatement();
        int res=stmt.executeUpdate(sql);
        if(res>0){
           b=true;
           //JOptionPane.showMessageDialog(null, "Insterted");
           
        }
        else{
           b=false;
           // JOptionPane.showMessageDialog(null, "Error");
           
        }
    }
    catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex);
    }
    return b;
}

public boolean RequestUser(int id){
    String LoginString="select * from Table1 where ID='"+id+"'";
    boolean b=false;
    try{
        pstmt=con_obj.prepareStatement(LoginString);
        res=pstmt.executeQuery();
        while(res.next()){
            name=res.getString("UserName");
            pwsd=res.getString("UserPass");
            b=true;
            
        }
        
    }
    catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex);
    }
    return b;
}

public boolean UpdateUser(String uemail,String upin){
     String LoginString="Update loginDetails SET Pin=? WHERE Email=?";
    boolean b=false;
  try{
      pstmt=con_obj.prepareStatement(LoginString);
      pstmt.setString(1, upin);
      pstmt.setString(2, uemail);
      int res=pstmt.executeUpdate();
      pstmt.close();
     if(res>0){
         b=true;
     }
     else{
         b=false;
     }

  }
  catch(Exception ex){
      
  }
  return b;
}
        
public boolean DeleteUser(int id){
    boolean b=false;
    
    String sql="delete from Table1 where ID='"+id+"'";
    try{
        stmt=con_obj.createStatement();
        int res=stmt.executeUpdate(sql);
        if(res>0){
           b=true;
           //JOptionPane.showMessageDialog(null, "Deleted");
           
        }
        else{
           b=false;
           // JOptionPane.showMessageDialog(null, "Error");
           
        }
    }
    catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex);
    }
    return b;
}

}
