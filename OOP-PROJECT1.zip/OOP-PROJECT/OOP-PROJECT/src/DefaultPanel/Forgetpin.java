package DefaultPanel;


import javax.swing.JOptionPane;

public class Forgetpin extends javax.swing.JFrame {
ConnectionToDb con_obj=new ConnectionToDb();
CRUD_Functions log=new CRUD_Functions();
  
    public Forgetpin() {
        initComponents();
         con_obj.EstablishConnection_1();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        uemail = new javax.swing.JTextField();
        upin = new javax.swing.JPasswordField();
        upin_confirm = new javax.swing.JPasswordField();
        back_login = new javax.swing.JButton();
        ChangePin = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Segoe Print", 1, 36)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Forget Pin ?");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 30, 290, 60));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Confirm Pin : ");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 210, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Enter Email :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 130, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Enter New Pin : ");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 170, -1, -1));

        uemail.setFont(new java.awt.Font("Yu Gothic UI", 0, 14)); // NOI18N
        uemail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uemailActionPerformed(evt);
            }
        });
        getContentPane().add(uemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 130, 190, -1));

        upin.setFont(new java.awt.Font("Yu Gothic UI", 0, 14)); // NOI18N
        upin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                upinActionPerformed(evt);
            }
        });
        getContentPane().add(upin, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 170, 190, -1));

        upin_confirm.setFont(new java.awt.Font("Yu Gothic UI", 0, 14)); // NOI18N
        upin_confirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                upin_confirmActionPerformed(evt);
            }
        });
        getContentPane().add(upin_confirm, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 210, 190, 30));

        back_login.setBackground(new java.awt.Color(255, 153, 0));
        back_login.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        back_login.setText("Back to Login");
        back_login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_loginActionPerformed(evt);
            }
        });
        getContentPane().add(back_login, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 280, 140, 30));

        ChangePin.setBackground(new java.awt.Color(255, 153, 0));
        ChangePin.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        ChangePin.setText("Change Pin");
        ChangePin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChangePinActionPerformed(evt);
            }
        });
        getContentPane().add(ChangePin, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 280, 140, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/forgetpinn.jpg"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 370));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void upin_confirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_upin_confirmActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_upin_confirmActionPerformed

    private void upinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_upinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_upinActionPerformed

    private void uemailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uemailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_uemailActionPerformed

    private void back_loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_loginActionPerformed
        // TODO add your handling code here:
        Login log=new Login();
        log.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_back_loginActionPerformed

    private void ChangePinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChangePinActionPerformed
        // TODO add your handling code here:
       String user,pin;
       boolean b;
       user=uemail.getText();
       pin=upin.getText();
       b=log.UpdateUser(user, pin);
       if(b){
       JOptionPane.showMessageDialog(null, "Pin Updated");
       }
       else{
           JOptionPane.showMessageDialog(null, "Error");
       }
       uemail.setText("");
       upin.setText("");
       upin_confirm.setText("");
    }//GEN-LAST:event_ChangePinActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Forgetpin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Forgetpin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Forgetpin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Forgetpin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Forgetpin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ChangePin;
    private javax.swing.JButton back_login;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JTextField uemail;
    private javax.swing.JPasswordField upin;
    private javax.swing.JPasswordField upin_confirm;
    // End of variables declaration//GEN-END:variables
}
